"""
virtstrap.exceptions
--------------------

Various exceptions.
"""

class CommandConfigError(Exception):
    """Exception for command configuration errors"""
    pass

class RequirementsConfigError(Exception):
    """Exception for command configuration errors"""
    pass
